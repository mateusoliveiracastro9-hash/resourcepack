# Players-Drop-Heads
Players drop their heads when killed by another player.
